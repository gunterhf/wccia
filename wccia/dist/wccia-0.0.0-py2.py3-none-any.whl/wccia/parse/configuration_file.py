conf = {
    'PROJECT': 'WCCIA',
    'NAS_FOLDER' : 'Q:\\GROUPS\\CORP_JGS_DSE\\ATI\\quotations',
    'DB_SERVER' : '10.0.36.129',
    'DB_PORT' : '34000/'
}
